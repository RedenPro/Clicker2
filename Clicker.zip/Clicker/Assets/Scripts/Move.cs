﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public float speed;
    public Vector2 direction;

    void Start()
    {

    }

    void FixedUpdate()
    {
        transform.Translate(direction.normalized * speed);
    }

    void Update()
    {

    }
}
