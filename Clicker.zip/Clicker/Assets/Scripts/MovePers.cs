﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePers : MonoBehaviour
{
    Rigidbody2D rg;

    void Start()
    {
        move();
    }


    void Update()
    {
        move();
    }

    void move()
    {
        rg.AddForce(transform.right * 3f, ForceMode2D.Force);
    }
}