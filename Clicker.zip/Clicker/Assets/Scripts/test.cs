﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour {

    Rigidbody2D rg;
    Animator anim;


    void Start () {

      rg = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }


    void Update()
    {


        if (Input.GetAxis("Horizontal") == 0)
        {
            anim.SetInteger("Anima", 2);
        }
        else
        {
            anim.SetInteger("Anima", 1);
        }


    }        

    void FixedUpdate() {
        rg.velocity = new Vector2 (Input.GetAxis("Horizontal") * 1.5f, rg.velocity.y);
    }
    
} 
