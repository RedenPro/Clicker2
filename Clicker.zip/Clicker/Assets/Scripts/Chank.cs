﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chank : MonoBehaviour {

    public Transform Begin;
    public Transform End;

    void Start () {
		
	}
	

	void Update () {
		
	}
}
