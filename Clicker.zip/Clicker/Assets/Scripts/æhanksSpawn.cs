﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class СhanksSpawn : MonoBehaviour {

    public Transform Player;
    public Chank[] ChankPrefabs;
    public Chank First;

    private List<Chank> spawnedChanks = new List<Chank> ();

	private void Start () 
    {
        spawnedChanks.Add(First);
	}
	

	private void Update () 
    {
        if(Player.position.x > spawnedChanks[spawnedChanks.Count - 1].End.position.x - 5)
        {
            SpawnChank();
        }
		
	}

    private void SpawnChank()
    {
        Chank newChank = Instantiate(ChankPrefabs[Random.Range(0, ChankPrefabs.Length)]);
        newChank.transform.position = spawnedChanks[spawnedChanks.Count-1].End.position - newChank.Begin.localPosition; 
        spawnedChanks.Add(newChank);

        if (spawnedChanks.Count >= 3)
        {
            Destroy(spawnedChanks[0].gameObject);
            spawnedChanks.RemoveAt(0);
        }
    }
}
